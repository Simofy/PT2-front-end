async function getApiCall() {
  const response = await fetch('https://simutis.dev/api/generate-shopping-cart');
  return await response.json();
}



window.addEventListener('load', function onLoad() {
  const tableBody = document.querySelector('tbody');
  function renderList(list) {
    list.forEach(function ({
      name,
      price,
      vegan
    }) {
      const trElm = document.createElement('tr');
      trElm.innerHTML = `
        <td>${name}</td>
        <td>${price}</td>
        <td>${vegan}</td>
      `;
      tableBody.appendChild(trElm);
    });
  }
  getApiCall().then(renderList)
    .catch(function (e) {
      console.error(e);
    });
});